/**
 * USB device communication for Samsung devices using WebUSB
 * Port of PyOdin's usb_device.py
 */

class DeviceInfo {
    constructor(vendorId, productId) {
        this.vendorId = vendorId;
        this.productId = productId;
        this.manufacturer = "";
        this.product = "";
        this.serialNumber = "";

        this.protocolVersion = 0;
        this.deviceId = "";
        this.modelName = "";
        this.firmwareVersion = "";
        this.chipId = "";
        this.supportsZlp = false;
    }

    toString() {
        return `DeviceInfo(product='${this.product}', model='${this.modelName}', serial='${this.serialNumber}')`;
    }
}

class UsbDevice {
    constructor(verbose = false) {
        this.verbose = verbose;
        this.device = null;
        this.interface = null;
        this.endpointOut = null;
        this.endpointIn = null;
        this.deviceInfo = null;
        this.packetSize = USB_PACKET_SIZE;
        this.configuration = null;
    }

    log(message) {
        if (this.verbose) {
            log(`[UsbDevice] ${message}`, "info");
        }
    }

    async findDevice() {
        this.log("Searching for Samsung device in Download mode...");

        try {
            const filters = SAMSUNG_DOWNLOAD_MODE_PIDS.map(pid => ({
                vendorId: SAMSUNG_VENDOR_ID,
                productId: pid
            }));

            this.device = await navigator.usb.requestDevice({ filters });

            if (!this.device) {
                return null;
            }

            this.log(
                `Found device: VID=0x${this.device.vendorId.toString(16).padStart(4, "0")}, ` +
                `PID=0x${this.device.productId.toString(16).padStart(4, "0")}`
            );

            this.deviceInfo = new DeviceInfo(
                this.device.vendorId,
                this.device.productId
            );

            this.deviceInfo.manufacturer = this.device.manufacturerName || "";
            this.deviceInfo.product = this.device.productName || "";
            this.deviceInfo.serialNumber = this.device.serialNumber || "";

            return this.deviceInfo;
        } catch (error) {
            log(`Error finding device: ${error.message}`, "error");
            return null;
        }
    }

    async connect() {
        if (!this.device) {
            const deviceInfo = await this.findDevice();
            if (!deviceInfo) {
                throw new Error("No Samsung device found in Download mode");
            }
        }

        try {
            this.log("Connecting to device...");
            await this.device.open();
            this.log("Device opened");

            if (this.device.configuration === null) {
                await this.device.selectConfiguration(1);
                this.log("Configuration selected");
            }

            this.configuration = this.device.configuration;

            if (!this.configuration) {
                throw new Error("No active USB configuration");
            }

            this.log(`Active configuration: ${this.configuration.configurationValue}`);
            this.log(`Number of interfaces: ${this.configuration.interfaces.length}`);

            this.endpointOut = null;
            this.endpointIn = null;
            this.interface = null;

            for (const iface of this.configuration.interfaces) {
                this.log(
                    `Interface ${iface.interfaceNumber}: ` +
                    `${iface.alternate.endpoints.length} endpoint(s)`
                );

                for (const alt of iface.alternates) {
                    this.log(
                        `  Alternate ${alt.alternateSetting}, class=${alt.interfaceClass}`
                    );

                    for (const ep of alt.endpoints) {
                        this.log(
                            `    Endpoint 0x${ep.endpointNumber.toString(16).padStart(2, "0")}: ` +
                            `${ep.type} ${ep.direction}, packetSize=${ep.packetSize}`
                        );
                    }
                }

                const alt = iface.alternate;
                const bulkIn = alt.endpoints.find(
                    ep => ep.type === "bulk" && ep.direction === "in"
                );
                const bulkOut = alt.endpoints.find(
                    ep => ep.type === "bulk" && ep.direction === "out"
                );

                if (!bulkIn || !bulkOut) {
                    this.log(`  Skipping interface ${iface.interfaceNumber}: no bulk IN/OUT pair`);
                    continue;
                }

                try {
                    await this.device.claimInterface(iface.interfaceNumber);
                    this.log(`  Claimed interface ${iface.interfaceNumber}`);
                } catch (error) {
                    this.log(
                        `  Could not claim interface ${iface.interfaceNumber}: ${error.message}`
                    );
                    continue;
                }

                this.interface = iface.interfaceNumber;
                this.endpointIn = bulkIn;
                this.endpointOut = bulkOut;

                this.log(
                    `  Selected matching bulk endpoint pair on interface ${this.interface}`
                );
                break;
            }

            if (
                !this.endpointOut ||
                !this.endpointIn ||
                this.interface === null
            ) {
                throw new Error(
                    "No successfully claimed interface has both bulk IN and OUT endpoints"
                );
            }

            this.log(
                `OUT: 0x${this.endpointOut.endpointNumber.toString(16).padStart(2, "0")}`
            );
            this.log(
                `IN:  0x${this.endpointIn.endpointNumber.toString(16).padStart(2, "0")}`
            );

            this.packetSize = this.endpointOut.packetSize;
            this.log(`Max packet size: ${this.packetSize}`);

            return true;
        } catch (error) {
            throw new Error(`USB connection failed: ${error.message}`);
        }
    }

    async disconnect() {
        if (this.device) {
            try {
                if (this.interface !== null) {
                    await this.device.releaseInterface(this.interface);
                }

                await this.device.close();
                this.log("Disconnected from device");
            } catch (error) {
                this.log(`Warning during disconnect: ${error.message}`);
            }
        }

        this.device = null;
        this.endpointOut = null;
        this.endpointIn = null;
        this.interface = null;
        this.configuration = null;
    }

    /**
     * Write data to the device.
     * timeout is in seconds; WebUSB itself does not accept this timeout.
     */
    async write(data, timeout = TIMEOUT_WRITE) {
        if (!this.endpointOut || !this.device) {
            throw new Error("Device not connected");
        }

        try {
            if (data.length > 65536) {
                let totalWritten = 0;
                let offset = 0;
                const chunkSize = 65536;

                while (offset < data.length) {
                    const chunkEnd = Math.min(offset + chunkSize, data.length);
                    const chunk = data.subarray(offset, chunkEnd);

                    const result = await this.device.transferOut(
                        this.endpointOut.endpointNumber,
                        chunk
                    );

                    const written = result.bytesWritten || 0;
                    totalWritten += written;
                    offset += written;

                    if (written !== chunk.length) {
                        this.log(
                            `Warning: Partial write ${written}/${chunk.length} bytes`
                        );
                        break;
                    }
                }

                if (this.verbose) {
                    this.log(`Wrote ${totalWritten} bytes (chunked)`);
                }

                return totalWritten;
            }

            const result = await this.device.transferOut(
                this.endpointOut.endpointNumber,
                data
            );

            if (this.verbose) {
                this.log(`Wrote ${result.bytesWritten} bytes`);
            }

            return result.bytesWritten;
        } catch (error) {
            throw new Error(`USB write failed: ${error.message}`);
        }
    }

    /**
     * Read data from the device.
     * timeout is in seconds.
     */
    async read(size, timeout = TIMEOUT_READ) {
        if (!this.endpointIn || !this.device) {
            throw new Error("Device not connected");
        }

        let timeoutId;

        try {
            const readPromise = this.device.transferIn(
                this.endpointIn.endpointNumber,
                size
            );

            const timeoutPromise = new Promise((_, reject) => {
                timeoutId = setTimeout(
                    () => reject(new Error("timeout")),
                    timeout * 1000
                );
            });

            const result = await Promise.race([
                readPromise,
                timeoutPromise
            ]);

            if (!result || !result.data) {
                throw new Error("USB response contained no data");
            }

            const view = result.data;

            if (this.verbose) {
                this.log(`Read ${view.byteLength} bytes`);
            }

            // Respect the actual DataView boundaries.
            return new Uint8Array(
                view.buffer,
                view.byteOffset,
                view.byteLength
            );
        } catch (error) {
            if (error.message === "timeout") {
                throw new Error(`USB read timeout after ${timeout}s`);
            }

            throw new Error(`USB read failed: ${error.message}`);
        } finally {
            if (timeoutId !== undefined) {
                clearTimeout(timeoutId);
            }
        }
    }

    async bulkWrite(data, timeout = TIMEOUT_WRITE) {
        let totalWritten = 0;
        let offset = 0;

        while (offset < data.length) {
            const chunkSize = Math.min(
                this.packetSize,
                data.length - offset
            );

            const chunk = data.subarray(offset, offset + chunkSize);
            const written = await this.write(chunk, timeout);

            totalWritten += written;

            if (written !== chunkSize) {
                throw new Error(
                    `Partial bulk write: ${written}/${chunkSize} bytes`
                );
            }

            offset += written;

            if (
                this.verbose &&
                totalWritten % (this.packetSize * 100) === 0
            ) {
                this.log(`Bulk write progress: ${totalWritten}/${data.length} bytes`);
            }
        }

        return totalWritten;
    }

    async bulkRead(size, timeout = TIMEOUT_READ) {
        const chunks = [];
        let totalRead = 0;

        while (totalRead < size) {
            const remaining = size - totalRead;
            const chunk = await this.read(
                Math.min(this.packetSize, remaining),
                timeout
            );

            if (chunk.length === 0) {
                break;
            }

            chunks.push(chunk);
            totalRead += chunk.length;
        }

        const output = new Uint8Array(totalRead);
        let offset = 0;

        for (const chunk of chunks) {
            output.set(chunk, offset);
            offset += chunk.length;
        }

        return output;
    }
}
